# 🎨 Assets Requeridos para WordPress.org

## 📋 Checklist de Archivos

Guarda todos los archivos en esta carpeta:

- [ ] **icon-128x128.png** - Icono del plugin (128x128 píxeles)
- [ ] **icon-256x256.png** - Icono retina (256x256 píxeles)
- [ ] **banner-772x250.png** - Banner principal (772x250 píxeles)
- [ ] **banner-1544x500.png** - Banner retina (1544x500 píxeles) [OPCIONAL]
- [ ] **screenshot-1.png** - Página de settings del plugin
- [ ] **screenshot-2.png** - Widget funcionando en sitio web
- [ ] **screenshot-3.png** - Vista móvil del widget

---

## 🎨 Especificaciones de Diseño

### Iconos (128x128 y 256x256)
- **Fondo**: Degradado verde (#00C185 → #00a372)
- **Ícono**: Burbuja de chat blanca
- **Estilo**: Flat, minimalista, moderno
- **Formato**: PNG con transparencia

### Banner (772x250)
- **Título**: "LeadWidget"
- **Subtítulo**: "AI Chat Widget for WhatsApp Leads"
- **Colores**: Verde emerald como acento
- **Incluir**: Logo o ícono a la izquierda

### Screenshots
- **Resolución**: Mínimo 1280x720
- **Formato**: PNG o JPG
- **Contenido**:
  1. Admin settings page con datos de ejemplo
  2. Widget abierto mostrando conversación
  3. Vista responsive en móvil

---

## 🔗 Herramientas Recomendadas

- **Canva**: https://www.canva.com/ (Gratis)
- **Figma**: https://www.figma.com/ (Gratis)
- **Photopea**: https://www.photopea.com/ (Gratis, similar a Photoshop)

---

## ✅ Una vez completados

Verificar que todos los archivos estén en esta carpeta, luego:

1. Ejecutar comando para crear ZIP final
2. Validar readme.txt en WordPress.org
3. Enviar solicitud de plugin

**Archivo creado**: 2026-02-06
