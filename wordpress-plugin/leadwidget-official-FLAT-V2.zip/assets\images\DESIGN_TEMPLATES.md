# 📐 Plantillas Exactas para Canva

## 🎯 ICONO DEL PLUGIN

### Diseño en Canva:

```
TAMAÑO: 512 x 512 px

CAPA 1 - Fondo:
┌────────────────────────────┐
│                            │
│  Degradado:                │
│  • Color superior: #00C185 │
│  • Color inferior: #00a372 │
│  • Dirección: 135° diagonal│
│                            │
└────────────────────────────┘

CAPA 2 - Ícono Chat Bubble:
     ╭───────╮
    │  💬   │  ← Blanco (#FFFFFF)
    │       │     Tamaño: 300x300px
     ╰──┘──╯      Centrado

CAPA 3 - Checkmark (opcional):
                  ✓✓  ← Blanco, pequeño
                      Esquina inferior derecha
```

**Elementos de Canva a buscar:**
- Fondo: `gradient square emerald`
- Ícono: `chat bubble outline` o `message icon`
- Checkmark: `double check mark`

---

## 🎨 BANNER (772 x 250)

### Layout:

```
┌──────────────────────────────────────────────────────────────┐
│                                                              │
│  [ICONO]    LeadWidget                                      │
│   200x200                                                    │
│             AI Chat Widget for WhatsApp Leads              │
│  (Verde)    ─────────────────────────────                  │
│                                                              │
└──────────────────────────────────────────────────────────────┘
  ← 150px →   ← Texto centrado verticalmente →
```

**Elementos:**

```
FONDO:
- Degradado horizontal: #00C185 (izq) → #1e293b (der)
- O patrón tech oscuro con overlay verde

ICONO (Izquierda):
- Copia el icono que creaste (512x512)
- Redimensiona a 180x180
- Posición: 35px del borde izquierdo, centrado verticalmente

TEXTO TÍTULO:
- Texto: "LeadWidget"
- Fuente: Montserrat Bold o Poppins Bold
- Tamaño: 64pt
- Color: #FFFFFF
- Posición: A 220px del borde izquierdo

TEXTO SUBTÍTULO:
- Texto: "AI Chat Widget for WhatsApp Leads"
- Fuente: Montserrat Regular
- Tamaño: 26pt
- Color: #FFFFFF opacidad 85%
- Posición: Debajo del título (gap 8px)

ELEMENTO DECORATIVO (opcional):
- Ícono WhatsApp pequeño (32x32)
- Color: #25D366 o blanco
- Al lado del subtítulo
```

---

## 📸 SCREENSHOTS - Qué Capturar

### Screenshot 1: Settings Page

**Preparación:**
1. Ve a WordPress Admin → LeadWidget
2. Rellena:
   - User ID: `DEMO123ABC`
   - Toggle: Activado (verde)
3. Asegúrate que se vea el badge verde "✓ Widget Active"

**Captura:**
- Desde el encabezado "LeadWidget Configuration"
- Hasta el botón "Save Settings"
- Incluye el sidebar con "Need Help?" y "Features"
- **NO incluir** la barra lateral izquierda de WordPress

**Herramienta:**
- Chrome Extension: "GoFullPage" (captura scrollable)
- O Win + Shift + S (recortar área específica)

---

### Screenshot 2: Widget en Acción

**Preparación:**
1. Abre el frontend del sitio WordPress
2. Espera que cargue el widget (5 segundos)
3. Click en el widget para abrirlo
4. Escribe: "Hola, quisiera información"
5. Espera respuesta del AI
6. Tener 2-3 mensajes visibles

**Captura:**
- Vista completa de la página web de fondo
- Widget abierto en esquina inferior derecha
- Conversación visible con mínimo 3 mensajes
- Asegúrate que se vea:
  - Header del widget ("En línea ahora")
  - Mensajes del usuario (verde)
  - Mensajes del asistente (blanco)
  - Input de texto

**Tamaño Ideal:**
- Ventana del navegador a 1920x1080
- Zoom al 100%

---

### Screenshot 3: Vista Móvil

**Preparación:**
1. En Chrome, presiona F12 (DevTools)
2. Click en ícono de dispositivos (Ctrl + Shift + M)
3. Selecciona: "iPhone 12 Pro" o "Samsung Galaxy S20"
4. Navega a la página con el widget
5. Click en widget (se adapta al móvil)

**Captura:**
- Solo el marco del móvil (no toda la pantalla de DevTools)
- Widget ocupando la pantalla móvil
- Conversación visible
- Se ve responsive y profesional

**Herramienta:**
- DevTools → Click derecho en el preview móvil
- "Capture screenshot" o "Capturar nodo"

---

## ✅ Checklist Final Antes de Exportar

### Iconos:
- [ ] Fondo degradado correcto (#00C185 → #00a372)
- [ ] Ícono de chat centrado y blanco
- [ ] Sin texto (solo ícono visual)
- [ ] Exportados en 128x128 Y 256x256

### Banner:
- [ ] Texto "LeadWidget" visible y legible
- [ ] Subtítulo descriptivo presente
- [ ] Colores de marca consistentes
- [ ] Logo/ícono a la izquierda
- [ ] Fondo atractivo pero no distrae del texto

### Screenshots:
- [ ] Screenshot 1: Settings page completa
- [ ] Screenshot 2: Widget interactuando
- [ ] Screenshot 3: Móvil responsive
- [ ] Todas mínimo 1280px de ancho
- [ ] Sin información personal/real visible
- [ ] Se ven profesionales

---

## 🎬 Orden Recomendado de Creación

**1. Icono (20 min)**
- Más rápido de hacer
- Lo reutilizas en el banner

**2. Banner (20 min)**
- Usa el icono que ya creaste

**3. Instalar WordPress Local (15 min)**
- Mientras se instala, toma un café ☕

**4. Screenshots (15 min)**
- Requiere WordPress funcionando
- Los 3 screenshots seguidos

**TOTAL: ~70 minutos**

---

## 💡 Tips Pro

### Para Canva:
- Usa la grilla (View → Show rulers)
- Alinea elementos con las guías automáticas
- Descarga siempre en PNG (mejor calidad)

### Para Screenshots:
- Usa modo incógnito del navegador (apariencia limpia)
- Cierra pestañas innecesarias
- Asegúrate buena iluminación en pantalla

### Para Mobile:
- En DevTools, también prueba landscape (horizontal)
- Toma múltiples capturas, elige la mejor

---

**¿Algún problema? Revisa ASSETS_NEEDED.md en esta carpeta.**
